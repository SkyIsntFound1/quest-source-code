& ./build.ps1
$env:qmodName = "GOOMPS"
$env:module_id = "goomps"
& ./CreateQmod.ps1