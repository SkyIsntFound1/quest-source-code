# Goodbye Moon Momke

When you flip someone off, you ascend to the heavens
