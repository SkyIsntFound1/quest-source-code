adb shell am force-stop com.AnotherAxiom.GorillaTag
adb shell am start com.AnotherAxiom.GorillaTag/com.unity3d.player.UnityPlayerActivity
